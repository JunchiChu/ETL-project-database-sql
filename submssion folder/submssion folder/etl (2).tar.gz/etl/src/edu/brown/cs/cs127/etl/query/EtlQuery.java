package edu.brown.cs.cs127.etl.query;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class EtlQuery
{
	private Connection conn;

	public EtlQuery(String pathToDatabase) throws Exception
	{
		Class.forName("org.sqlite.JDBC");
		conn = DriverManager.getConnection("jdbc:sqlite:" + pathToDatabase);

		Statement stat = conn.createStatement();
		stat.executeUpdate("PRAGMA foreign_keys = ON;");
	}

	public ResultSet query1(String[] args) throws SQLException
	{
		/**
		 * For some sample JDBC code, check out 
		 * http://web.archive.org/web/20100814175321/http://www.zentus.com/sqlitejdbc/
		 */
		PreparedStatement stat = conn.prepareStatement(
			"SELECT col1, col2 FROM table WHERE col3 = ? AND col4 = ?"
		);
		stat.setString(1, args[0]);
		stat.setInt(2, Integer.parseInt(args[1]));
		return stat.executeQuery();
	}

	public ResultSet query2(String[] args) throws SQLException
	{
		return null;
	}
}
